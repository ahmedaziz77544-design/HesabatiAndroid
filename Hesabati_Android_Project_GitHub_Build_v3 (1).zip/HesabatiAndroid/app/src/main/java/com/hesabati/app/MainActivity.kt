package com.hesabati.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Entry(
    val kind: String,
    val title: String,
    val amount: Double,
    val currency: String,
    val date: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                HesabatiApp(this)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HesabatiApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("hesabati_local", Context.MODE_PRIVATE) }
    var entries by remember { mutableStateOf(loadEntries(prefs)) }
    var tab by remember { mutableStateOf("الرئيسية") }
    var showAdd by remember { mutableStateOf(false) }
    val tabs = listOf("الرئيسية", "المبيعات", "المشتريات", "المصروفات", "التقارير")
    val currencies = listOf("YER", "SAR", "USD")

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("حساباتي", fontWeight = FontWeight.Bold)
                            Text("شركة حساباتي للأنظمة المحاسبية", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        Text("نسخة تجريبية", modifier = Modifier.padding(end = 12.dp), style = MaterialTheme.typography.labelSmall)
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة عملية")
                }
            },
            bottomBar = {
                NavigationBar {
                    tabs.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "الرئيسية" -> Icons.Default.Home
                                        "المبيعات" -> Icons.Default.PointOfSale
                                        "المشتريات" -> Icons.Default.ShoppingCart
                                        "المصروفات" -> Icons.Default.ReceiptLong
                                        else -> Icons.Default.BarChart
                                    },
                                    contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                "الرئيسية" -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("ملخص النشاط", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("تُعرض كل عملة بشكل مستقل دون خلط أسعار الصرف", style = MaterialTheme.typography.bodySmall)
                    }
                    items(currencies) { currency -> CurrencySummaryBlock(currency, entries) }
                    item {
                        Text("أحدث العمليات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    items(entries.takeLast(8).reversed()) { entry -> EntryCard(entry) }
                    if (entries.isEmpty()) {
                        item { Text("لا توجد عمليات مسجلة بعد. اضغط زر + لإضافة أول عملية.", modifier = Modifier.padding(vertical = 12.dp)) }
                    }
                    item { Spacer(Modifier.height(72.dp)) }
                }
                "التقارير" -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("التقارير الأولية", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("صافي الحركة محسوب داخل العملة نفسها فقط.", style = MaterialTheme.typography.bodySmall)
                    }
                    items(currencies) { currency -> CurrencySummaryBlock(currency, entries) }
                    item { Spacer(Modifier.height(72.dp)) }
                }
                else -> {
                    val filtered = entries.filter { it.kind == tab }.reversed()
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text(tab, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                        if (filtered.isEmpty()) {
                            item { Text("لا توجد عمليات مسجلة بعد", modifier = Modifier.padding(16.dp)) }
                        } else {
                            items(filtered) { entry -> EntryCard(entry) }
                        }
                        item { Spacer(Modifier.height(72.dp)) }
                    }
                }
            }
        }

        if (showAdd) {
            AddEntryDialog(
                onDismiss = { showAdd = false },
                onSave = { entry ->
                    entries = entries + entry
                    saveEntries(prefs, entries)
                    showAdd = false
                }
            )
        }
    }
}

@Composable
fun CurrencySummaryBlock(currency: String, entries: List<Entry>) {
    val sales = entries.filter { it.kind == "مبيعات" && it.currency == currency }.sumOf { it.amount }
    val purchases = entries.filter { it.kind == "مشتريات" && it.currency == currency }.sumOf { it.amount }
    val expenses = entries.filter { it.kind == "مصروفات" && it.currency == currency }.sumOf { it.amount }
    val net = sales - purchases - expenses

    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("ملخص $currency", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            SummaryLine("المبيعات", sales, currency)
            SummaryLine("المشتريات", purchases, currency)
            SummaryLine("المصروفات", expenses, currency)
            HorizontalDivider()
            SummaryLine("صافي الحركة", net, currency, emphasize = true)
        }
    }
}

@Composable
fun SummaryLine(label: String, amount: Double, currency: String, emphasize: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontWeight = if (emphasize) FontWeight.Bold else FontWeight.Normal)
        Text(
            "%,.2f %s".format(Locale.US, amount, currency),
            fontWeight = if (emphasize) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
fun EntryCard(entry: Entry) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(entry.title, fontWeight = FontWeight.SemiBold)
                Text("${entry.kind} • ${entry.date}", style = MaterialTheme.typography.labelSmall)
            }
            Text(
                "%,.2f %s".format(Locale.US, entry.amount, entry.currency),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEntryDialog(onDismiss: () -> Unit, onSave: (Entry) -> Unit) {
    var kind by remember { mutableStateOf("مبيعات") }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("YER") }
    var kindExpanded by remember { mutableStateOf(false) }
    var currencyExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة عملية جديدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ExposedDropdownMenuBox(expanded = kindExpanded, onExpandedChange = { kindExpanded = !kindExpanded }) {
                    OutlinedTextField(
                        value = kind,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("نوع العملية") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(kindExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = kindExpanded, onDismissRequest = { kindExpanded = false }) {
                        listOf("مبيعات", "مشتريات", "مصروفات").forEach { option ->
                            DropdownMenuItem(text = { Text(option) }, onClick = { kind = option; kindExpanded = false })
                        }
                    }
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("البيان / اسم العملية") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("المبلغ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                ExposedDropdownMenuBox(expanded = currencyExpanded, onExpandedChange = { currencyExpanded = !currencyExpanded }) {
                    OutlinedTextField(
                        value = currency,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("العملة") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(currencyExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = currencyExpanded, onDismissRequest = { currencyExpanded = false }) {
                        listOf("YER", "SAR", "USD").forEach { option ->
                            DropdownMenuItem(text = { Text(option) }, onClick = { currency = option; currencyExpanded = false })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parsedAmount = amount.trim().replace(',', '.').toDoubleOrNull()
                if (title.isNotBlank() && parsedAmount != null && parsedAmount > 0.0) {
                    val date = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date())
                    onSave(Entry(kind, title.trim(), parsedAmount, currency, date))
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

fun loadEntries(prefs: android.content.SharedPreferences): List<Entry> {
    return try {
        val array = JSONArray(prefs.getString("entries", "[]"))
        (0 until array.length()).map { index ->
            val item = array.getJSONObject(index)
            Entry(
                item.getString("kind"),
                item.getString("title"),
                item.getDouble("amount"),
                item.getString("currency"),
                item.getString("date")
            )
        }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveEntries(prefs: android.content.SharedPreferences, entries: List<Entry>) {
    val array = JSONArray()
    entries.forEach { entry ->
        array.put(
            JSONObject()
                .put("kind", entry.kind)
                .put("title", entry.title)
                .put("amount", entry.amount)
                .put("currency", entry.currency)
                .put("date", entry.date)
        )
    }
    prefs.edit().putString("entries", array.toString()).apply()
}
